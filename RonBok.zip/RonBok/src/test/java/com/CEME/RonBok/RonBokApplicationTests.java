package com.CEME.RonBok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RonBokApplicationTests {

	@Test
	void contextLoads() {
	}

}
