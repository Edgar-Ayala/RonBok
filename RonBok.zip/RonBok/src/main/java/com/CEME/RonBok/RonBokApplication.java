package com.CEME.RonBok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RonBokApplication {

	public static void main(String[] args) {
		SpringApplication.run(RonBokApplication.class, args);
	}

}
